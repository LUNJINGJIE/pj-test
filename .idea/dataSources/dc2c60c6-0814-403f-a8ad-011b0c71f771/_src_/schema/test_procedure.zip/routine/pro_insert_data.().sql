CREATE PROCEDURE pro_insert_data()
  BEGIN
	#Routine body goes here...
	DECLARE n BIGINT;
	set n = 20;
	while n <= 25
	DO
	insert into users (student_ID)VALUES(n);
	set n = n + 1;
	end WHILE;
END;
