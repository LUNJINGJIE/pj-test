CREATE PROCEDURE `add`()
  BEGIN
	#Routine body goes here...
	DECLARE tmp BIGINT DEFAULT 0;
DECLARE cur CURSOR FOR SELECT student_ID FROM users;

DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' set tmp = 0;
OPEN cur;
FETCH cur INTO tmp;
WHILE(tmp != 0)
DO
SELECT tmp;

UPDATE users
SET student_ID = tmp + 100
WHERE student_ID = tmp;
FETCH cur INTO tmp;
END WHILE;
CLOSE cur;
END;
